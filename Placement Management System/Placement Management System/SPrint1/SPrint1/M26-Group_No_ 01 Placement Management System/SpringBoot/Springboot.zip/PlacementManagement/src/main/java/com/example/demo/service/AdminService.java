package com.example.demo.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Admin;
import com.example.demo.repository.AdminRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AdminService {
	
	@Autowired
	private AdminRepository repo;
	
	//to retrieve all the data of student class
	public List<Admin> listAll()
	{
		return repo.findAll();
	}
	//insert/create/update a data
	public void create(Admin s)
	{
		 repo.save(s);
	}
	//to retrieve a single record
	public Admin retrieve(Integer id)
	{
		return repo.findById(id).get();
		
	}
	//to delete a data
	public void delete(Integer id)
	{
		repo.deleteById(id);
	}

}
